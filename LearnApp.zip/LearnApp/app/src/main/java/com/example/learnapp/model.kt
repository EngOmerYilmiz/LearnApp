package com.example.learnapp

data class Hobby(var title: String)

object Supplier{

    val hobbies = listOf<Hobby>(
        Hobby("Reading"),
        Hobby("Swimming"),
        Hobby("Writing"),
        Hobby("Gaming"),
        Hobby("Walking"),
        Hobby("Learning"),
        Hobby("Watching"),
        Hobby("Reading"),
        Hobby("Swimming"),
        Hobby("Writing"),
        Hobby("Gaming"),
        Hobby("Walking"),
        Hobby("Learning"),
        Hobby("Watching"),
        Hobby("Reading"),
        Hobby("Swimming"),
        Hobby("Writing"),
        Hobby("Gaming"),
        Hobby("Walking"),
        Hobby("Learning"),
        Hobby("Watching")
        )

}